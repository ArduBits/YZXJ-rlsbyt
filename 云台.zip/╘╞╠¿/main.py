
from time import time
from maix import serial #导入库
ser = serial.Serial("/dev/ttyS1",115200) #设置端口
ser_str="0" #数据初始化

class Retinaface():
    mud_path = "./retinaface_int8.mud"
    variances = [0.1, 0.2]
    steps = [8, 16, 32]
    min_sizes = [16, 32, 64, 128, 256, 512]

    def __init__(self) -> None:
        from maix import nn
        self.model = nn.load(self.mud_path,opt = None)
        from maix.nn import decoder
        self.decoder = decoder.Retinaface([224,224] , self.steps , self.min_sizes, self.variances)

    def __del__(self):
        del self.model
        del self.decoder

    def cal_fps(self ,start , end):
        one_second = 1
        one_flash = end - start
        fps = one_second / one_flash
        return  fps

    def  draw_fps(self,img , fps):
        img.draw_string(0, 0 ,'FPS :'+str(fps), scale=1,color=(255, 0, 255), thickness=1)


    def draw_rectangle(self,img, box):
        img.draw_rectangle(box[0], box[1], box[2], box[3],color=(230 ,230, 250), thickness=2)

    def draw_point(self,img,landmark):
        for i in range(5):
            x = landmark[2 * i ]
            y = landmark[2 * i + 1]
            img.draw_rectangle(x-2,y-2, x+2,y+2,color= (193 ,255 ,193), thickness =-1)


    def process(self,input):
        out = self.model.forward(input, quantize=1, layout = "chw") # retinaface decoder only support chw layout
        boxes , landmarks = self.decoder.run(out, nms = 0.2 ,score_thresh = 0.7 , outputs_shape =[[1,4,2058],[1,2,2058],[1,10,2058]])
        global ser_str
        for i,box in enumerate(boxes):
            self.draw_rectangle(input,box)
            self.draw_point(input , landmarks[i])
            x_mind = (box[2] - box[0])/2 + box[0]
            y_mind = (box[3] - box[1])/2 + box[1]
            if x_mind >= 140 :
                ser_str = "yz"
                ser.write(ser_str.encode('utf-8'))
            elif x_mind <= 80 :
                ser_str = "zz"
                ser.write(ser_str.encode('utf-8'))
            if y_mind >= 140 :
                ser_str = "sz"
                ser.write(ser_str.encode('utf-8'))
            elif y_mind <= 80 :
                ser_str = "xz"
                ser.write(ser_str.encode('utf-8'))


def main():
    from maix import display, camera
    app  = Retinaface()

    while True:
        img = camera.capture().resize(size=(224,224))
        app.process(img)
        display.show(img)
        # break
main()
